#packages <- c("rAmCharts", "shinydashboard", "shiny", "ggplot2", "highcharter", "DT")

#new.packages <- packages[!(packages %in% installed.packages[,"Package"])]
#if(length(new.packages)) install.packages(new.packages, repos='http://cran.us.r-project.org'）

#for (p in packages) {install.packages(p, repos='http://cran.us.r-project.org')}

setwd("G:/WMG/Academic Courses/Project/6. Dashboard/New ADG")

library(shinydashboard)
library(shiny)
library(ggplot2)
library(rAmCharts)
library(highcharter)
library(DT)

# Datete setting. Sys.Date() gets the system date, and then days are subtracted for other variables.
today <- Sys.Date()
date <- format(today, format = "%Y-%m-%d")
yesterday <- format(today - 1, format = "%d-%m-%Y")

#-------------------------------------------------
# SERVER "myserver"
#-------------------------------------------------
# Build the server part of the code - this is where the charts are generated.
myserver <- function(input, output) {
  #------------------------------------
  # UpdateTimeCSV
  #------------------------------------
  output$messageMenu <- renderText({
    invalidateLater(600000)
    updateData <-
      read.csv(file = "updateTime.csv",
               header = TRUE,
               sep = ",")
    names(updateData) <- NULL
    ut <- toString(unlist(updateData))
    return(ut)
  })
  
  #------------------------------------
  # CONTENT OF TAB 1
  #------------------------------------
  #------------------------------------
  # SHOW CHART ON BOX T1.F1.B1
  #------------------------------------
  output$chartT1F1B1 <- renderAmCharts({
    invalidateLater(600000)
    data01a <-
      read.csv(file = "01asocialmediafollowers.csv",
               header = TRUE,
               sep = ",")
    data01a$DateValue <-
      as.Date(data01a$DateValue, format = "%Y-%m-%d")
    
    data01asubset <-
      subset(data01a,
             DateValue >= input$daterange3,
             DateValue <= input$daterange4)
    data01asubset <-
      subset(data01asubset, DateValue <= input$daterange4)
    data01asubset <- subset(data01asubset, DateValue < date)
    
    data01asubset$DateValue <-
      as.POSIXlt(data01asubset$DateValue, tz = "", format = "%Y/%m/%d")
    
    amTimeSeries(
      data = data01asubset,
      col_date = 'DateValue',
      col_series = c(
        'LinkedIn',
        'Twitter',
        'Facebook'
      ),
      main = 'Social Media Followers',
      ylab = 'Numbers',
      bullet = 'round',
      bulletSize = 7,
      linetype = c(0, 0, 0),
      fillAlphas = c(0, 0, 0),
      export = TRUE,
      maxSeries = 12,
      ZoomButton = data.frame(
        Unit = c('MM', 'MM', 'MM', 'MM', 'MM'),
        multiple = c(100, 12, 6, 3, 1),
        label = c('All time', '12 Months', '6 Months', '3 Months', 'Last Month')
      ),
      scrollbar = TRUE,
      scrollbarHeight = 20
    )
  })
  
  #------------------------------------
  # SHOW CHART ON BOX T1.F1.B2
  #------------------------------------
  output$chartT1F1B2 <- renderAmCharts({
    invalidateLater(600000)
    data01b <-
      read.csv(file = "01asocialmediakpi.csv",
               header = TRUE,
               sep = ",")
    x <- as.numeric(data01b$Rate)
    bands = data.frame(start = c(0, 40, 60), end = c(40, 60, 100), 
                   color = c("#00CC00", "#ffac29", "#ea3838"),
                   stringsAsFactors = FALSE)
    amAngularGauge(
        x, 
        export = TRUE, 
        main = "Followers KPI Progress",
        data = data01b, 
        bands = bands
    )
  })


  #------------------------------------
  # SHOW CHART ON BOX T1.F2.B1
  #------------------------------------
  output$chartT1F2B1 <- renderAmCharts({
    invalidateLater(600000)
    data01c <-
      read.csv(file = "01cpublication.csv",
               header = TRUE,
               sep = ",")
    title <- paste("Subscription Rate of Journals")
    amBarplot(
      data = data01c,
      x = "Quarter",
      y = c('Views', 'Subscription'),
      export = TRUE,
      xlab = "Date",
      ylab = "Number of",
      depth = 0,
      labelRotation = -45,
      main = title,
      rotate = FALSE,
      legend = TRUE,
      layered = TRUE,
      legendPosition = "bottom"
    )
  })
  #------------------------------------
  # SHOW CHART ON BOX T1.F2.B2
  #------------------------------------
  output$chartT1F2B2 <- renderAmCharts({
    invalidateLater(600000)
    data01d <-
      read.csv(file = "01dviewskpi.csv",
               header = TRUE,
               sep = ",")
    x <- as.numeric(data01d$Rate)
        bands = data.frame(start = c(0, 40, 60), end = c(40, 60, 100), 
                   color = c("#00CC00", "#ffac29", "#ea3838"),
                   stringsAsFactors = FALSE)

    amAngularGauge(
        x, 
        export = TRUE, 
        main = "Subscription KPI Progress",
        data = data01d, 
        bands = bands
    )
  })
  
  

  #------------------------------------
  # CLICK HELP ON BOX T1.F1.B1
  #------------------------------------
  # Observe the event of clicking the question mark. When it happens it run this code. Notice that the ID of the help button is shown after "input$"
  observeEvent(input$helpT1F1B1, {
    # show modal means make a modal pop-up with this text
    showModal(modalDialog(
      # title is set here - tags$b means "<b>" in html ... i.e. make bold
      title = tags$b("Chart Title Goes Here"),
      # first line in itallics "<i>"
      tags$div(
        tags$i("First line of the help information goes here"),
        # equivalent to </br> ... add a break to the text
        tags$br(),
        tags$br(),
        # text goes in here
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      # easyClose means that the user clicking anywhere on the screen will close the modal
      easyClose = TRUE,
      # bottom will have a close button still
      footer = modalButton("Close")
    ))
  })
  # End of help button
  #------------------------------------
  # CLICK HELP ON BOX T1.F1.B2
  #------------------------------------
  observeEvent(input$helpT1F1B2, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })

  #------------------------------------
  # CLICK HELP ON BOX T1.F2.B1
  #------------------------------------
  observeEvent(input$helpT1F2B1, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      # easyClose means that the user clicking anywhere on the screen will close the modal
      easyClose = TRUE,
      # bottom will have a close button still
      footer = modalButton("Close")
    ))
  })
  # End of help button
  #------------------------------------
  # CLICK HELP ON BOX T1.F2.B2
  #------------------------------------
  observeEvent(input$helpT1F2B2, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      # easyClose means that the user clicking anywhere on the screen will close the modal
      easyClose = TRUE,
      # bottom will have a close button still
      footer = modalButton("Close")
    ))
  })
  # End of help button
  #------------------------------------
  # CONTENT OF TAB 2
  #------------------------------------
  #------------------------------------
  # SHOW CHART ON BOX T2.F1.B1
  #------------------------------------
  output$chartT2F1B1 <- renderAmCharts({
    invalidateLater(600000)
    data02a <-
      read.csv(file = "02aimpactfactors.csv",
               header = TRUE,
               sep = ",")
    data02a$Year <- as.character(data02a$Year)
    title <- paste("Ranking of Journals")
    amBarplot(
      x = "Year",
      y = c('ImpactFactors', 'Ranking'),
      data = data02a,
      export = TRUE, 
      xlab = "Date",
      ylab = "Number of",
      depth = 0,
      labelRotation = -45,
      main = title,
      rotate = FALSE,
      legend = TRUE,
      layered = FALSE,
      legendPosition = "bottom"
    )
  })
  #------------------------------------
  # SHOW CHART ON BOX T2.F1.B2
  #------------------------------------
  output$chartT2F1B2 <- renderAmCharts({
    invalidateLater(600000)
    data02b <-
      read.csv(file = "02bfinancialinput.csv",
               header = TRUE,
               sep = ",")
    title <- paste("Financial Input in OR Research")
    amBarplot(
      data = data02b,
      x = "Month",
      y = "FinancialInput",
      export = TRUE, 
      groups_color = "#87CEEB",
      xlab = "Month",
      ylab = "Pounds",
      dataDateFormat = NULL,
      precision = 2,
      depth = 0,
      labelRotation = -45,
      main = title,
      show_values = FALSE,
      rotate = FALSE,
      legend = FALSE,
      layered = FALSE,
      legendPosition = "bottom"
    )
  })
  
  #------------------------------------
  # CLICK HELP ON BOX T2.F1.B1
  #------------------------------------
  observeEvent(input$helpT2F1B1, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  #------------------------------------
  # CLICK HELP ON BOX T2.F1.B2
  #------------------------------------
  observeEvent(input$helpT2F1B2, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  #------------------------------------
  # CONTENT OF TAB 3
  #------------------------------------
  #------------------------------------
  # SHOW CHART ON BOX T3.F1.B1
  #------------------------------------
  output$chartT3F1B1 <- renderAmCharts({
    invalidateLater(600000)
    data03a <-
      read.csv(file = "03aconferences.csv",
               header = TRUE,
               sep = ",")
    title <- paste("Conferences per Quater")
    amBarplot(
      data = data03a,
      x = "Quarter",
      y = "Conferences",
      export = TRUE, 
      groups_color = "#87CEEB",
      xlab = "Quater ",
      ylab = "Pounds",
      depth = 0,
      labelRotation = -45,
      main = title,
      rotate = FALSE,
      legend = FALSE,
      layered = FALSE,
      legendPosition = "bottom"
    )
  })
  #------------------------------------
  # SHOW CHART ON BOX T3.F1.B2
  #------------------------------------
  output$chartT3F1B2 <- renderAmCharts({
    invalidateLater(600000)
    data03b <-
      read.csv(file = "03bconferenceskpi.csv",
               header = TRUE,
               sep = ",")
    x <- as.numeric(data03b$Rate)
        bands = data.frame(start = c(0, 40, 60), end = c(40, 60, 100), 
                   color = c("#00CC00", "#ffac29", "#ea3838"),
                   stringsAsFactors = FALSE)

    amAngularGauge(
        x, 
        export = TRUE, 
        main = "Conference KPI Progress",
        data = data03b, 
        bands = bands
    )
  })
  
  #------------------------------------
  # SHOW CHART ON BOX T3.F2.B1.A
  #------------------------------------
  output$chartT3F2B1A <- renderAmCharts({
    invalidateLater(600000)
    data03c1 <-
      read.csv(file = "03cevents.csv",
               header = TRUE,
               sep = ",")
    title <- paste("Numbers of Networking Event")
    amBarplot(
      data = data03c1,
      x = "Quarter",
      y = "Events",
      export = TRUE, 
      groups_color = "#87CEEB",
      xlab = "Quarter",
      ylab = "Number of",
      depth = 0,
      labelRotation = -45,
      main = title,
      rotate = FALSE,
      legend = FALSE,
      layered = FALSE,
      stack_type = "regular",
      legendPosition = "bottom"
    )
  })
  #------------------------------------
  # SHOW CHART ON BOX T3.F2.B1.B
  #------------------------------------
  output$chartT3F2B1B <- renderAmCharts({
    invalidateLater(600000)
    data03c2 <-
      read.csv(file = "03cevents.csv",
               header = TRUE,
               sep = ",")
    title <- paste("Participants per Event")
    amBarplot(
      data = data03c2,
      x = "Quarter",
      y = "ParticipantperEvent",
      export = TRUE, 
      groups_color = "#FFD700",
      xlab = "Quarter",
      ylab = "Number of",
      depth = 0,
      labelRotation = -45,
      main = title,
      rotate = FALSE,
      legend = FALSE,
      layered = FALSE,
      stack_type = "regular",
      legendPosition = "bottom"
    )
  })
  #------------------------------------
  # SHOW CHART ON BOX T3.F2.B2
  #------------------------------------
  output$chartT3F2B2 <- renderAmCharts({
    invalidateLater(600000)
    data03d <-
      read.csv(file = "03dattendencekpi.csv",
               header = TRUE,
               sep = ",")
    x <- as.numeric(data03d$Rate)
        bands = data.frame(start = c(0, 40, 60), end = c(40, 60, 100), 
                   color = c("#00CC00", "#ffac29", "#ea3838"),
                   stringsAsFactors = FALSE)
    amAngularGauge(
        x, 
        export = TRUE, 
        main = "Participant KPI Progress",
        data = data03d, 
        bands = bands
    )
  })

  #------------------------------------
  # CLICK HELP ON BOX T3.F1.B1
  #------------------------------------
  observeEvent(input$helpT3F1B1, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  # END OF HELP BUTTON
  #------------------------------------
  # CLICK HELP ON BOX T3.F1.B2
  #------------------------------------
  observeEvent(input$helpT3F1B2, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  # END OF HELP BUTTON
  #------------------------------------
  # CLICK HELP ON BOX T3.F2.B1.A
  #------------------------------------
  observeEvent(input$helpT3F2B1A, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  # END OF HELP BUTTON
  #------------------------------------
  observeEvent(input$helpT3F2B1B, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  # END OF HELP BUTTON
  #------------------------------------
  observeEvent(input$helpT3F2B2, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  # END OF HELP BUTTON
  #------------------------------------
  # CONTENT OF TAB 4
  #------------------------------------
  #------------------------------------
  # SHOW CHART ON BOX T4.F1.B1.A
  #------------------------------------
  output$chartT4F1B1A <- renderAmCharts({
    invalidateLater(600000)
    data04a1 <-
      read.csv(file = "04atraining.csv",
               header = TRUE,
               sep = ",")
    title <- paste("Number of people trained")
    amBarplot(
      data = data04a1,
      x = "Quarter",
      y = c('ORSocietyBookings', 'AnalyticsBookings'),
      export = TRUE, 
      xlab = "Date",
      ylab = "Number of",
      depth = 0,
      labelRotation = -45,
      main = title,
      rotate = FALSE,
      legend = TRUE,
      layered = TRUE,
      legendPosition = "bottom"
    )
  })

  # SHOW CHART ON BOX T4.F1.B1.B
  #------------------------------------
  output$chartT4F1B1B <- renderAmCharts({
    invalidateLater(600000)
    data04a2 <-
      read.csv(file = "04atraining.csv",
               header = TRUE,
               sep = ",")
    title <- paste("Number of Courses Run")
    amBarplot(
      data = data04a2,
      x = "Quarter",
      y = c('ORSocietyCourses', 'AnalyticsCourses'),
      export = TRUE, 
      xlab = "Date",
      ylab = "Number of",
      depth = 0,
      labelRotation = -45,
      main = title,
      rotate = FALSE,
      legend = TRUE,
      layered = TRUE,
      legendPosition = "bottom"
    )
  }) 
  # SHOW CHART ON BOX T4.F1.B2
  #------------------------------------
  output$chartT4F1B2 <- renderAmCharts({
    invalidateLater(600000)
    data04b <-
      read.csv(file = "04battendencekpi.csv",
               header = TRUE,
               sep = ",")
    x <- as.numeric(data04b$Rate)
        bands = data.frame(start = c(0, 40, 60), end = c(40, 60, 100), 
                   color = c("#00CC00", "#ffac29", "#ea3838"),
                   stringsAsFactors = FALSE)
    amAngularGauge(
        x, 
        export = TRUE, 
        main = "Participant KPI Progress",
        data = data04b, 
        bands = bands
    )
  })

  # SHOW CHART ON BOX T4.F2.B1
  #------------------------------------
  output$chartT4F2B1 <- renderAmCharts({
    invalidateLater(600000)
    data04c <-
      read.csv(file = "04cawards.csv",
               header = TRUE,
               sep = ",")
    data04c$Year <- as.character(data04c$Year)
    title <- paste("Analytics Stream Conference Papers")
    amBarplot(
      data = data04c,
      x = "Year",
      y = c('Awards', 'Certificates'),
      export = TRUE, 
      xlab = "Year",
      ylab = "Number of",
      depth = 0,
      labelRotation = -45,
      main = title,
      rotate = FALSE,
      legend = TRUE,
      layered = FALSE,
      stack_type = "regular",
      legendPosition = "bottom"
    )
  })
  #------------------------------------
  # CLICK HELP ON BOX T4.F1.B1.A
  #------------------------------------
  observeEvent(input$helpT4F1B1A, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  # END OF HELP BUTTON
  #------------------------------------
  # CLICK HELP ON BOX T4.F1.B1.B
  #------------------------------------
  observeEvent(input$helpT4F1B1B, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  # END OF HELP BUTTON
  #------------------------------------
  # CLICK HELP ON BOX T4.F1.B2
  #------------------------------------
  observeEvent(input$helpT4F1B2, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  # END OF HELP BUTTON
  #------------------------------------
  # CLICK HELP ON BOX T4.F2.B1
  #------------------------------------
  observeEvent(input$helpT4F2B1, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  # END OF HELP BUTTON
  #------------------------------------
  # CONTENT OF TAB 5
  #------------------------------------
  #------------------------------------
  # sHOW CHART ON BOX T5.F1.B1
  #------------------------------------
  output$chartT5F1B1 <- renderAmCharts({
    invalidateLater(600000)
    data05a <-
      read.csv(file = "05aprobonoprojects.csv",
               header = TRUE,
               sep = ",")
    title <- paste("Completed ProBono Projects")
    amBarplot(
      data = data05a,
      x = "Quarter",
      y = c('ProBonoProjects', 'PBAnalyticsProjects'),
      export = TRUE, 
      xlab = "Quarter",
      ylab = "Projects Completed in Quarter",
      depth = 0,
      labelRotation = 0,
      main = title,
      rotate = FALSE,
      legend = TRUE,
      legendPosition = "bottom",
      layered = TRUE
    )
  })
  #------------------------------------
  # SHOW CHART ON BOX T5.F1.B2
  #------------------------------------
  output$chartT5F1B2 <- renderAmCharts({
    invalidateLater(600000)
    data05b <-
      read.csv(file = "05bprojectkpi.csv",
               header = TRUE,
               sep = ",")
    x <- as.numeric(data05b$Rate)
        bands = data.frame(start = c(0, 40, 60), end = c(40, 60, 100), 
                   color = c("#00CC00", "#ffac29", "#ea3838"),
                   stringsAsFactors = FALSE)

    amAngularGauge(
        x, 
        export = TRUE, 
        main = "PB Project KPI Progress",
        data = data05b, 
        bands = bands
    )
  })
  #------------------------------------
  # sHOW CHART ON BOX T5.F2.B1
  #------------------------------------
  output$chartT5F2B1 <- renderAmCharts({
    invalidateLater(600000)
    data05c <-
      read.csv(file = "05cvolunteers.csv",
               header = TRUE,
               sep = ",")
    title <- paste("Volunteers per Project")
    amBarplot(
      data = data05c,
      x = "Quarter",
      y = "Volunteers",
      export = TRUE, 
      groups_color = "#87CEEB",
      xlab = "Quarter",
      ylab = "Volunteers per Project",
      depth = 0,
      labelRotation = 0,
      main = title,
      rotate = FALSE,
      legend = FALSE,
      legendPosition = "bottom",
      layered = FALSE
    )
  })
  #------------------------------------
  # sHOW CHART ON BOX T5.F2.B2
  #------------------------------------
  output$chartT5F2B2 <- renderAmCharts({
    invalidateLater(600000)
    data05d <-
      read.csv(file = "05dvolunteerskpi.csv",
               header = TRUE,
               sep = ",")
    x <- as.numeric(data05d$Rate)
    title <- paste("Volunteers KPI Progress")
        bands = data.frame(start = c(0, 40, 60), end = c(40, 60, 100), 
                   color = c("#00CC00", "#ffac29", "#ea3838"),
                   stringsAsFactors = FALSE)

    amAngularGauge(
        x, 
        export = TRUE, 
        main = "Volunteers KPI Progress",
        data = data05d, 
        bands = bands
    )
  })
  #------------------------------------
  # CLICK HELP ON BOX T5.F1.B1
  #------------------------------------
  observeEvent(input$helpT5F1B1, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  # END OF HELP BUTTON
  #------------------------------------
  # CLICK HELP ON BOX T5.F1.B2
  #------------------------------------
  observeEvent(input$helpT5F1B2, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  # END OF HELP BUTTON
  #------------------------------------
  # CLICK HELP ON BOX T5.F2.B1
  #------------------------------------
  observeEvent(input$helpT5F2B1, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  # END OF HELP BUTTON
  #------------------------------------
  # CLICK HELP ON BOX T5.F2.B2
  #------------------------------------
  observeEvent(input$helpT5F2B2, {
    showModal(modalDialog(
      title = tags$b("Chart Title Goes Here"),
      tags$div(
        tags$i("First line of the help information goes here"),
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text",
        tags$br(),
        tags$br(),
        "Help text"
      ),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
  })
  # END OF HELP BUTTON
}
# END OF SERVER
#-----------------------------------------
# SIDEBAR UI ELEMENT "mysidebar"
#-----------------------------------------
mysidebar <- dashboardSidebar(
  sidebarMenu(
    # each menu item has display name, internal ID, and then the icon used on the UI
    menuItem(
      "Reach Analytics",
      tabName = "Tab1",
      icon = icon("dashboard")
    ),
    menuItem(
      "OR Research Analytics",
      tabName = "Tab2",
      icon = icon("dashboard")
    ),
    menuItem(
      "Community Analytics",
      tabName = "Tab3",
      icon = icon("dashboard")
    ),
    menuItem(
      "Capacibility Analytics",
      tabName = "Tab4",
      icon = icon("dashboard")
    ),
    menuItem(
      "Visibility Analytics",
      tabName = "Tab5",
      icon = icon("dashboard")
    ),
    # inputs follow the pattern: internal id, the label (h5 is an html command for the display, initial value
    # (null means) today, and, as this is a date, the format)
    dateInput(
      "daterange3",
      label = h5("Start date"),
      value = "2016-01-01",
      format = "dd/mm/yyyy"
    ),
    dateInput(
      "daterange4",
      label = h5("End date"),
      value = NULL,
      format = "dd/mm/yyyy"
    )
    # again, label, then the options (showing text to display first and then internal reference), selected is the
    
  ) #closes the sidebar menu
) #closes the dashboatd "sidebar" element creation

#-----------------------------------------
# BODY UI ELEMENT "mybody"
#-----------------------------------------
mybody <- dashboardBody(tabItems(
  #-------------------------------------------------------------------
  # TAB T1 CONTENT (linked back to the sidebar)
  #-------------------------------------------------------------------
  tabItem(
    tabName = "Tab1",
    # you can ignore this next line
    tags$head(tags$script(src = "min.js")),
    # this line sets the font style for the header
    tags$head(tags$style(
      HTML(
        '.main-header .logo {font-family: "Veranda", Times, "Times New Roman", serif;font-weight: bold; font-size: 26px;}'
      )
    )),
    # under each tab is a series of rows, fluid because they will adapt to screen size
    #
    # FLUID ROW T1.F1
    fluidRow(
      # in each row there are boxes. Boxes are a certain height (auto usually), width (number of columns - 12 max),
      # the action link references a modal pop-up with information (see below).
      # This link is internal name, display name (left blank) and icon and the library where the icon lives.
      # The next part (amChartsOuput) is the thing to display. In this case an amChart with the id given.
      #BOX T1.F1.B1
      box(
        actionLink(
          "helpT1F1B1",
          "",
          icon = icon("question-circle", lib = "font-awesome")
        ),
        amChartsOutput(outputId = "chartT1F1B1")
      ),
      #BOX T1.F1.B2
      box(
        actionLink(
          "helpT1F1B2",
          "",
          icon = icon("question-circle", lib = "font-awesome")
        ),
        amChartsOutput(outputId = "chartT1F1B2")
      )
    ),
    # FLUID ROW T1.F2
    fluidRow(
      #BOX T1.F2.B1
      box(
        actionLink(
          "helpT1F2B1",
          "",
          icon = icon("question-circle", lib = "font-awesome")
        ),
        amChartsOutput(outputId = "chartT1F2B1")
      ),
       #BOX T1.F2.B2
      box(
        actionLink(
          "helpT1F2B2",
          "",
          icon = icon("question-circle", lib = "font-awesome")
        ),
        amChartsOutput(outputId = "chartT1F2B2")
      )
    )),
  # fluid row ends, next row starts. (the 4 widths above add up to 12 for 12 columns)
  #
  # this is the end of the tab. It then moves to the next tab
  #-------------------------------------------------------------------
  # TAB T2
  #-------------------------------------------------------------------
  tabItem(tabName = "Tab2",
          # FLUID ROW T2.F1
          fluidRow(
            # BOX T2.F1.B1
            box(
              actionLink(
                "helpT2F1B1",
                "",
                icon = icon("question-circle", lib = "font-awesome")
              ),
              amChartsOutput(outputId = "chartT2F1B1")
            ),
            # BOX T2.F1.B2
            box(
              actionLink(
                "helpT2F1B2",
                "",
                icon = icon("question-circle", lib = "font-awesome")
              ),
              amChartsOutput(outputId = "chartT2F1B2")
            )
          )),
  #-------------------------------------------------------------------
  # TAB T3
  #-------------------------------------------------------------------
  
  tabItem(tabName = "Tab3",
          # FLUID ROW T3.F1
          fluidRow(
            # BOX T3.F1.B1
            box(
              actionLink(
                "helpT3F1B1",
                "",
                icon = icon("question-circle", lib = "font-awesome")
              ),
              amChartsOutput(outputId = "chartT3F1B1")
            ),
            # BOX T3.F1.B2
            box(
              actionLink(
                "helpT3F1B2",
                "",
                icon = icon("question-circle", lib = "font-awesome")
              ),
              amChartsOutput(outputId = "chartT3F1B2")
            )
          ),

          # FLUID ROW T3.F2
           fluidRow(
            # BOX T3.F2.B1.A
            tabBox(
              tabPanel(
               "Networking Event", 
               amChartsOutput(outputId = "chartT3F2B1A")
            ),
            # BOX T3.F2.B1.B
            tabPanel(
               "Participants", 
                amChartsOutput(outputId = "chartT3F2B1B")
            )),
            # BOX T3.F2.B2
            box(
              actionLink(
                "helpT3F2B2",
                "",
                icon = icon("question-circle", lib = "font-awesome")
              ),
              amChartsOutput(outputId = "chartT3F2B2")
            )
          )),
  
  #-------------------------------------------------------------------
  # TAB T4
  #-------------------------------------------------------------------
  
  tabItem(tabName = "Tab4",
          # FLUID ROW T4.F1
          fluidRow(
            # BOX T4.F1.B1.A
            tabBox(
              tabPanel(
               "People",
               amChartsOutput(outputId = "chartT4F1B1A")
              ),
            # BOX T4.F1.B1.B
            tabPanel(
               "Courses",
               amChartsOutput(outputId = "chartT4F1B1B")
              ) 
            ),
            # BOX T4.F1.B2
            box(
              actionLink(
                "helpT4F1B2",
                "",
                icon = icon("question-circle", lib = "font-awesome")
              ),
              amChartsOutput(outputId = "chartT4F1B2")
            )
           ),
          # FLUID ROW T4.F2
          fluidRow(
            # BOX T4.F2.B1
            box(
              actionLink(
                "helpT4F2B1",
                "",
                icon = icon("question-circle", lib = "font-awesome")
              ),
              amChartsOutput(outputId = "chartT4F2B1")
            )
          )),
  
  #-------------------------------------------------------------------
  # TAB T5
  #-------------------------------------------------------------------
  tabItem(
    tabName = "Tab5",
    # FLUID ROW T5.F1
    fluidRow(
            # BOX T5.F1.B1
            box(
              actionLink(
                "helpT5F1B1",
                "",
                icon = icon("question-circle", lib = "font-awesome")
              ),
              amChartsOutput(outputId = "chartT5F1B1")
            ),
            # BOX T5.F1.B2
            box(
              actionLink(
                "helpT5F1B2",
                "",
                icon = icon("question-circle", lib = "font-awesome")
              ),
              amChartsOutput(outputId = "chartT5F1B2")
            )
          ),
          # FLUID ROW T5.F2
          fluidRow(
            # BOX T5.F2.B1
            box(
              actionLink(
                "helpT5F2B1",
                "",
                icon = icon("question-circle", lib = "font-awesome")
              ),
              amChartsOutput(outputId = "chartT5F2B1")
            ),
            # BOX T5.F2.B2
            box(
              actionLink(
                "helpT5F2B2",
                "",
                icon = icon("question-circle", lib = "font-awesome")
              ),
              amChartsOutput(outputId = "chartT5F2B2")
            )
    ))

))
# End of Tab 5
# End of the body element
#-----------------------------------------
# HEADER UI ELEMENT "myheader"
#-----------------------------------------
myheader <- dashboardHeader(
  title = "ADG Dashboard",
  titleWidth = 300,
  dropdownMenu(
    type = "notifications",
    notificationItem(
      text = verbatimTextOutput("messageMenu"),
      icon = icon("calendar"),
      status = "success"
    )
  )
)
#-----------------------------------------
# USER INTERFACE "myui"
#-----------------------------------------
myui <- dashboardPage(# skin is the background colour - google the package shinydashboard for details
  skin = "red",
  # set the header size and title - don't bother with notifications
  myheader,
  # include the sidebar we made earlier
  mysidebar,
  # include the body we made earlier and the UI is done
  mybody)
#-----------------------------------------
# RUN THE SHINYAPP
#-----------------------------------------
# let's put it all together!
# ui is the first component - this is the bit we aleady did SIDEBAR + BODY
shinyApp(ui = myui, server = myserver)




